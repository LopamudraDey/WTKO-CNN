import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from torch.cuda.amp import autocast, GradScaler
from tensorflow.keras.preprocessing.sequence import pad_sequences
import torch.nn.functional as F
# Define the dataset class
class SequenceDataset(Dataset):
    def __init__(self, sequences, labels):
        self.sequences = sequences
        self.labels = labels

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, idx):
        seq = torch.tensor(self.sequences[idx], dtype=torch.float32)
        label = torch.tensor(self.labels[idx], dtype=torch.long)
        return seq, label

import torch
import torch.nn as nn
import torch.nn.functional as F

class CNN_LSTM_Model(nn.Module):
    def __init__(self):
        super(CNN_LSTM_Model, self).__init__()
        
        # CNN layers
        self.conv1 = nn.Conv1d(in_channels=4, out_channels=64, kernel_size=10)
        self.pool1 = nn.MaxPool1d(kernel_size=2)
        self.dropout1 = nn.Dropout(0.3)

        self.conv2 = nn.Conv1d(in_channels=64, out_channels=128, kernel_size=10)
        self.pool2 = nn.MaxPool1d(kernel_size=2)
        self.dropout2 = nn.Dropout(0.3)

        # After 2 conv+pool layers, calculate reduced sequence length
        # Original: 500 → conv1 (491) → pool1 (245) → conv2 (236) → pool2 (118)
        self.lstm_input_length = 118
        self.lstm_input_channels = 128

        # LSTM layer
        self.lstm = nn.LSTM(input_size=self.lstm_input_channels, hidden_size=128, num_layers=1, batch_first=True, bidirectional=True)

        # Fully connected layers
        self.fc1 = nn.Linear(128 * 2, 64)  # bidirectional LSTM → 2*hidden
        self.fc2 = nn.Linear(64, 2)        # binary classification

    def forward(self, x):
        # Input: (batch_size, seq_len, 4) → Permute for CNN
        x = x.permute(0, 2, 1)  # (batch_size, 4, seq_len)

        x = self.pool1(F.relu(self.conv1(x)))
        x = self.dropout1(x)
        x = self.pool2(F.relu(self.conv2(x)))
        x = self.dropout2(x)

        # Prepare for LSTM: (batch_size, channels, seq_len) → (batch_size, seq_len, channels)
        x = x.permute(0, 2, 1)  # (batch_size, lstm_seq_len, lstm_input_channels)

        # LSTM layer
        lstm_out, _ = self.lstm(x)  # (batch_size, seq_len, 2*hidden)
        lstm_out = lstm_out[:, -1, :]  # Use last time step output

        # Fully connected layers
        x = F.relu(self.fc1(lstm_out))
        x = self.fc2(x)
        return x
# Loss function: BCEWithLogitsLoss
criterion = nn.BCEWithLogitsLoss()

# Training loop remains the same

# Function to one-hot encode sequences
nucleotides = {'A': [1, 0, 0, 0],
               'C': [0, 1, 0, 0],
               'G': [0, 0, 1, 0],
               'T': [0, 0, 0, 1],
               'N': [0, 0, 0, 0]}

def one_hot_encode(sequences, seq_length=None):
    encoded_sequences = []
    for seq in sequences:
        seq = seq.upper()
        encoded_seq = np.array([nucleotides[base] for base in seq])
        if seq_length:
            encoded_seq = pad_sequences([encoded_seq], maxlen=seq_length, padding='post', dtype='float16')[0]
        encoded_sequences.append(encoded_seq)
    return np.array(encoded_sequences)

# Load your data (replace with your actual file paths)
#wt_df = pd.read_csv('F:/GSE149836/LSD_WT.csv', delimiter=';')
#ko_df = pd.read_csv('F:/GSE149836/LSD_KO.csv', delimiter=';')
wt_df = pd.read_csv('Ebf1specific_600bp.tsv', delimiter="\t")
ko_df = pd.read_csv('Ebf1KOspecific_600bp.tsv', delimiter="\t")
#wt_df = pd.read_csv('D:/LOPAGPU/wt_specificfile.csv', delimiter=";")
#ko_df = pd.read_csv('D:/LOPAGPU/ebf1ko_specificfile.csv', delimiter=";")
wt_df["label"] = 1
ko_df["label"] = 0
# Get the minimum sample size
min_size = min(len(wt_df), len(ko_df))

# Sample equal number from each
wt_balanced = wt_df.sample(n=min_size, random_state=42)
ko_balanced = ko_df.sample(n=min_size, random_state=42)
df = pd.concat([wt_balanced, ko_balanced], ignore_index=True)

# Combine the data
#df = pd.concat([wt_df, ko_df], ignore_index=True)
#df.to_csv("combined_file_train.csv")

# Split into training and testing data (exclude chromosomes 6 and 7 for training)
train_df = df[~df['chrom'].isin(['chr6', 'chr7'])]
test_df = df[df['chrom'].isin(['chr6', 'chr7'])]

# Extract sequences and labels
X_train = train_df['sequence'].values
y_train = train_df['label'].values
X_test = test_df['sequence'].values
y_test = test_df['label'].values

# One-hot encode the sequences (setting a sequence length of 1000)
trainencoded_sequences = one_hot_encode(X_train, seq_length=600)
testencoded_sequences = one_hot_encode(X_test, seq_length=600)

# Create datasets and dataloaders
train_dataset = SequenceDataset(trainencoded_sequences, y_train)
test_dataset = SequenceDataset(testencoded_sequences, y_test)

train_loader = DataLoader(train_dataset, batch_size=16, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=16, shuffle=False)

# Initialize the model, loss function, optimizer, and scaler
model = CNN_LSTM_Model()
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)
scaler = GradScaler()  # For mixed precision

# Training loop with gradient accumulation
epochs = 20
accumulation_steps = 4  # Simulate larger batch size by accumulating gradients

for epoch in range(epochs):
    model.train()
    running_loss = 0.0
    correct = 0
    total = 0

    for i, (inputs, labels) in enumerate(train_loader):
        optimizer.zero_grad()

        # Use automatic mixed precision (AMP) for faster training and reduced memory usage
        with autocast():  # Mixed Precision
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss = loss / accumulation_steps  # Normalize the loss

        # Backpropagation
        scaler.scale(loss).backward()

        # Update weights after accumulation
        if (i + 1) % accumulation_steps == 0:
            scaler.step(optimizer)
            scaler.update()
            optimizer.zero_grad()

        running_loss += loss.item()
        # Compute accuracy
        _, predicted = torch.max(outputs, 1)  # Get the predicted class
        correct += (predicted == labels).sum().item()
        total += labels.size(0)

    # Compute final accuracy
    accuracy = 100 * correct / total
    # Print the loss for this epoch
    print(f"Epoch [{epoch+1}/{epochs}], Loss: {running_loss / len(train_loader):.4f}, Accuracy: {accuracy:.2f}%")
# Evaluation on test data
model.eval()
correct = 0
total = 0

with torch.no_grad():
    for inputs, labels in test_loader:
        outputs = model(inputs)
        _, predicted = torch.max(outputs.data, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()

accuracy = 100 * correct / total
print(f"Test Accuracy: {accuracy:.2f}%")
# Save the model state_dict
#torch.save(model.state_dict(), 'modelcnnLSTM.pth')  # mo

from sklearn.metrics import confusion_matrix, classification_report
import numpy as np
model.eval()
all_preds = []
all_labels = []

with torch.no_grad():
    for inputs, labels in test_loader:
        outputs = model(inputs)
        _, predicted = torch.max(outputs.data, 1)
        all_preds.extend(predicted.cpu().numpy())
        all_labels.extend(labels.cpu().numpy())

# Convert lists to numpy arrays
all_preds = np.array(all_preds)
all_labels = np.array(all_labels)

# Confusion Matrix
cm = confusion_matrix(all_labels, all_preds)
print("Confusion Matrix:")
print(cm)

# Classification Report
report = classification_report(all_labels, all_preds, target_names=["WT", "KO"])
print("\nClassification Report:")
print(report)
