import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from torch.cuda.amp import autocast, GradScaler
from tensorflow.keras.preprocessing.sequence import pad_sequences
import torch.nn.functional as F
# Define the dataset class
class SequenceDataset(Dataset):
    def __init__(self, sequences, labels):
        self.sequences = sequences
        self.labels = labels

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, idx):
        seq = torch.tensor(self.sequences[idx], dtype=torch.float32)
        label = torch.tensor(self.labels[idx], dtype=torch.long)
        return seq, label

class SequenceModel(nn.Module):
    def __init__(self):
        super(SequenceModel, self).__init__()

        # First convolutional layer
        self.conv1 = nn.Conv1d(in_channels=4, out_channels=64, kernel_size=10)
        self.pool1 = nn.MaxPool1d(kernel_size=2)
        self.dropout1 = nn.Dropout(0.3)

        # Second convolutional layer
        self.conv2 = nn.Conv1d(in_channels=64, out_channels=128, kernel_size=10)
        self.pool2 = nn.MaxPool1d(kernel_size=2)
        self.dropout2 = nn.Dropout(0.3)

        # Third convolutional layer (added)
        self.conv3 = nn.Conv1d(in_channels=128, out_channels=256, kernel_size=10)
        self.pool3 = nn.MaxPool1d(kernel_size=2)
        self.dropout3 = nn.Dropout(0.3)

        # Fourth convolutional layer (added)
        self.conv4 = nn.Conv1d(in_channels=256, out_channels=512, kernel_size=10)
        self.pool4 = nn.MaxPool1d(kernel_size=2)
        self.dropout4 = nn.Dropout(0.3)

        #self.conv5 = nn.Conv1d(in_channels=512, out_channels=1024, kernel_size=10)
        #self.pool5 = nn.MaxPool1d(kernel_size=2)
        #self.dropout5 = nn.Dropout(0.3)
        # Calculate flatten dimension after all pooling layers
        # Assuming input sequence length is 500
        input_length = 600

        # After conv1 and pool1
        input_length = (input_length - 10 + 1) // 2

        # After conv2 and pool2
        input_length = (input_length - 10 + 1) // 2

        # After conv3 and pool3
        input_length = (input_length - 10 + 1) // 2

        # After conv4 and pool4
        input_length = (input_length - 10 + 1) // 2
        #input_length = (input_length - 10 + 1) // 2


        # Flatten dimension after all convolutional and pooling layers
        self.flatten_dim = 512 * input_length

        # Fully connected layers
        self.fc1 = nn.Linear(self.flatten_dim, 256)  # Increased the size of the fully connected layer
        self.fc2 = nn.Linear(256, 64)  # Additional fully connected layer (added)

        # Output layer for binary classification
        self.output = nn.Linear(64, 2)  # Two outputs for binary classification

    def forward(self, x):
        x = x.permute(0, 2, 1)  # Change dimensions for Conv1d: (batch_size, channels, sequence_length)

        # Pass through first convolutional layer
        x = self.pool1(F.relu(self.conv1(x)))
        x = self.dropout1(x)

        # Pass through second convolutional layer
        x = self.pool2(F.relu(self.conv2(x)))
        x = self.dropout2(x)

        # Pass through third convolutional layer (newly added)
        x = self.pool3(F.relu(self.conv3(x)))
        x = self.dropout3(x)

        # Pass through fourth convolutional layer (newly added)
        x = self.pool4(F.relu(self.conv4(x)))
        x = self.dropout4(x)
       # x = self.pool4(F.relu(self.conv5(x)))
        #x = self.dropout5(x)
        # Flatten the output from the last convolutional layer
        x = x.view(x.size(0), -1)  # Flatten

        # Pass through fully connected layers
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))  # Additional fully connected layer (newly added)

        # Output layer (raw logits for CrossEntropyLoss)
        x = self.output(x)
        return x
# Loss function: BCEWithLogitsLoss
criterion = nn.BCEWithLogitsLoss()

# Training loop remains the same

# Function to one-hot encode sequences
nucleotides = {'A': [1, 0, 0, 0],
               'C': [0, 1, 0, 0],
               'G': [0, 0, 1, 0],
               'T': [0, 0, 0, 1],
               'N': [0, 0, 0, 0]}

def one_hot_encode(sequences, seq_length=None):
    encoded_sequences = []
    for seq in sequences:
        seq = seq.upper()
        encoded_seq = np.array([nucleotides[base] for base in seq])
        if seq_length:
            encoded_seq = pad_sequences([encoded_seq], maxlen=seq_length, padding='post', dtype='float16')[0]
        encoded_sequences.append(encoded_seq)
    return np.array(encoded_sequences)

# Load your data (replace with your actual file paths)
#wt_df = pd.read_csv('wt_specificfile.csv', delimiter=";")
#back_df = pd.read_csv('back_1000.csv', delimiter=";")
#wt_df = pd.read_csv('Enhancer_Positive_512.csv',delimiter=";")
#back_df=pd.read_csv("Enhancer_Negative_512.csv",delimiter=";")
wt_df = pd.read_csv('LSD_WT.csv',delimiter=";")
back_df=pd.read_csv("LSD_KO.csv",delimiter=";")
import pandas as pd
wt_df["label"] = 1
back_df["label"] = 0
# Get the minimum sample size
min_size = min(len(wt_df), len(back_df))

# Sample equal number from each
wt_balanced = wt_df.sample(n=min_size, random_state=42)
back_balanced = back_df.sample(n=min_size, random_state=42)
df = pd.concat([wt_balanced, back_balanced], ignore_index=True)

# Split into training and testing data (exclude chromosomes 6 and 7 for training)
train_df = df[~df['chrom'].isin(['chr6', 'chr7'])]
test_df = df[df['chrom'].isin(['chr6', 'chr7'])]

# Extract sequences and labels
X_train = train_df['sequence'].values
y_train = train_df['label'].values
X_test = test_df['sequence'].values
y_test = test_df['label'].values

# One-hot encode the sequences (setting a sequence length of 1000)
trainencoded_sequences = one_hot_encode(X_train, seq_length=600)
testencoded_sequences = one_hot_encode(X_test, seq_length=600)

# Create datasets and dataloaders
train_dataset = SequenceDataset(trainencoded_sequences, y_train)
test_dataset = SequenceDataset(testencoded_sequences, y_test)

train_loader = DataLoader(train_dataset, batch_size=16, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=16, shuffle=False)

# Initialize the model, loss function, optimizer, and scaler
model = SequenceModel()
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)
scaler = GradScaler()  # For mixed precision

# Training loop with gradient accumulation
epochs = 70
accumulation_steps = 4  # Simulate larger batch size by accumulating gradients

for epoch in range(epochs):
    model.train()
    running_loss = 0.0
    correct = 0
    total = 0

    for i, (inputs, labels) in enumerate(train_loader):
        optimizer.zero_grad()

        # Use automatic mixed precision (AMP) for faster training and reduced memory usage
        with autocast():  # Mixed Precision
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss = loss / accumulation_steps  # Normalize the loss

        # Backpropagation
        scaler.scale(loss).backward()

        # Update weights after accumulation
        if (i + 1) % accumulation_steps == 0:
            scaler.step(optimizer)
            scaler.update()
            optimizer.zero_grad()

        running_loss += loss.item()
        # Compute accuracy
        _, predicted = torch.max(outputs, 1)  # Get the predicted class
        correct += (predicted == labels).sum().item()
        total += labels.size(0)

    # Compute final accuracy
    accuracy = 100 * correct / total
    # Print the loss for this epoch
    print(f"Epoch [{epoch+1}/{epochs}], Loss: {running_loss / len(train_loader):.4f}, Accuracy: {accuracy:.2f}%")
# Evaluation on test data
model.eval()
correct = 0
total = 0

with torch.no_grad():
    for inputs, labels in test_loader:
        outputs = model(inputs)
        _, predicted = torch.max(outputs.data, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()

accuracy = 100 * correct / total
print(f"Test Accuracy: {accuracy:.2f}%")
# Save the model state_dict
torch.save(model.state_dict(), 'RelaWTvsKO_4layersmodel_600.pth')
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report,ConfusionMatrixDisplay   

# Put model in evaluation mode
model.eval()

all_preds = []
all_labels = []

with torch.no_grad():
    for inputs, labels in test_loader:
        outputs = model(inputs)
        _, predicted = torch.max(outputs.data, 1)
        all_preds.extend(predicted.cpu().numpy())
        all_labels.extend(labels.cpu().numpy())

# Calculate accuracy manually
correct = sum(p == l for p, l in zip(all_preds, all_labels))
total = len(all_labels)
accuracy = 100 * correct / total
print(f"Test Accuracy: {accuracy:.2f}%")

# Print classification report
print("\nClassification Report:")
print(classification_report(all_labels, all_preds, target_names=['WT', 'KO']))

# Confusion matrix
cm = confusion_matrix(all_labels, all_preds)
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['WT', 'KO'])

# Plot confusion matrix
plt.figure(figsize=(5, 4))
disp.plot(cmap=plt.cm.Blues)
plt.savefig("confusion_Rela_600_fixed4layers.png", dpi=300, bbox_inches='tight')
plt.title("Confusion Matrix")
plt.show()
train_losses = []
train_accuracies = []

for epoch in range(epochs):
    model.train()
    running_loss = 0.0
    correct = 0
    total = 0

    for i, (inputs, labels) in enumerate(train_loader):
        optimizer.zero_grad()

        with autocast():
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss = loss / accumulation_steps

        scaler.scale(loss).backward()

        if (i + 1) % accumulation_steps == 0:
            scaler.step(optimizer)
            scaler.update()
            optimizer.zero_grad()

        running_loss += loss.item()
        _, predicted = torch.max(outputs, 1)
        correct += (predicted == labels).sum().item()
        total += labels.size(0)

    epoch_loss = running_loss / len(train_loader)
    epoch_accuracy = 100 * correct / total

    train_losses.append(epoch_loss)
    train_accuracies.append(epoch_accuracy)

    print(f"Epoch [{epoch+1}/{epochs}], Loss: {epoch_loss:.4f}, Accuracy: {epoch_accuracy:.2f}%")

# Plot Epoch vs Loss
plt.figure(figsize=(10,4))
plt.subplot(1,2,1)
plt.plot(range(1, epochs+1), train_losses, marker='o', color='blue')
plt.title("Epoch vs Loss")
plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.grid(True)

# Plot Epoch vs Accuracy
plt.subplot(1,2,2)
plt.plot(range(1, epochs+1), train_accuracies, marker='o', color='green')
plt.title("Epoch vs Accuracy")
plt.xlabel("Epoch")
plt.ylabel("Accuracy (%)")
plt.grid(True)

plt.tight_layout()
plt.savefig("Relaloss_accuracy.png", dpi=300)
plt.show()