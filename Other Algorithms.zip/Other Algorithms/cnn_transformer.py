import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

import pandas as pd
import numpy as np

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    classification_report
)

# ======================================
# Device
# ======================================

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(device)

# ======================================
# One-hot encoding
# ======================================

NUC = {
    "A":[1,0,0,0],
    "C":[0,1,0,0],
    "G":[0,0,1,0],
    "T":[0,0,0,1],
    "N":[0,0,0,0]
}

def one_hot(sequences,max_len=600):

    encoded=[]

    for seq in sequences:

        seq=seq.upper()

        arr=np.array([NUC.get(x,[0,0,0,0]) for x in seq],dtype=np.float32)

        if len(arr)<max_len:

            pad=np.zeros((max_len-len(arr),4),dtype=np.float32)

            arr=np.vstack((arr,pad))

        else:

            arr=arr[:max_len]

        encoded.append(arr)

    return np.array(encoded)


# ======================================
# Dataset
# ======================================

class SeqDataset(Dataset):

    def __init__(self,X,y):

        self.X=X

        self.y=y

    def __len__(self):

        return len(self.X)

    def __getitem__(self,index):

        return (
            torch.tensor(self.X[index],dtype=torch.float32),
            torch.tensor(self.y[index],dtype=torch.long)
        )


# ======================================
# CNN + Transformer
# ======================================

class CNNTransformer(nn.Module):

    def __init__(self,seq_len=600):

        super().__init__()

        self.conv1=nn.Conv1d(4,64,kernel_size=10)

        self.bn1=nn.BatchNorm1d(64)

        self.conv2=nn.Conv1d(64,128,kernel_size=15)

        self.bn2=nn.BatchNorm1d(128)

        self.pool=nn.MaxPool1d(2)

        self.dropout=nn.Dropout(0.3)

        dummy=torch.zeros(1,4,seq_len)

        with torch.no_grad():

            dummy=self.pool(F.relu(self.bn1(self.conv1(dummy))))

            dummy=self.pool(F.relu(self.bn2(self.conv2(dummy))))

        L=dummy.shape[-1]

        self.pos_embedding=nn.Parameter(torch.randn(1,L,128))

        encoder=nn.TransformerEncoderLayer(
            d_model=128,
            nhead=8,
            dim_feedforward=512,
            dropout=0.2,
            batch_first=True
        )

        self.transformer=nn.TransformerEncoder(
            encoder,
            num_layers=3
        )

        self.fc1=nn.Linear(128,64)

        self.fc2=nn.Linear(64,2)

    def forward(self,x):

        x=x.permute(0,2,1)

        x=self.pool(F.relu(self.bn1(self.conv1(x))))

        x=self.dropout(x)

        x=self.pool(F.relu(self.bn2(self.conv2(x))))

        x=self.dropout(x)

        x=x.permute(0,2,1)

        x=x+self.pos_embedding

        x=self.transformer(x)

        x=torch.mean(x,dim=1)

        x=F.relu(self.fc1(x))

        x=self.fc2(x)

        return x


# ======================================
# Main
# ======================================

if __name__=="__main__":

    wt=pd.read_csv("Ebf1specific_600bp.tsv",sep="\t")

    ko=pd.read_csv("Ebf1KOspecific_600bp.tsv",sep="\t")

    wt["label"]=1

    ko["label"]=0

    n=min(len(wt),len(ko))

    wt=wt.sample(n,random_state=42)

    ko=ko.sample(n,random_state=42)

    df=pd.concat([wt,ko],ignore_index=True)

    train=df[~df["chrom"].isin(["chr6","chr7"])]

    test=df[df["chrom"].isin(["chr6","chr7"])]

    X_train=one_hot(train.sequence.values)

    X_test=one_hot(test.sequence.values)

    y_train=train.label.values

    y_test=test.label.values

    train_loader=DataLoader(
        SeqDataset(X_train,y_train),
        batch_size=32,
        shuffle=True
    )

    test_loader=DataLoader(
        SeqDataset(X_test,y_test),
        batch_size=32,
        shuffle=False
    )

    model=CNNTransformer().to(device)

    optimizer=torch.optim.Adam(model.parameters(),lr=1e-3)

    criterion=nn.CrossEntropyLoss()

    epochs=20

    best_acc=0

    for epoch in range(epochs):

        model.train()

        total_loss=0

        for x,y in train_loader:

            x=x.to(device)

            y=y.to(device)

            optimizer.zero_grad()

            outputs=model(x)

            loss=criterion(outputs,y)

            loss.backward()

            optimizer.step()

            total_loss+=loss.item()

        print(f"Epoch {epoch+1} Loss {total_loss/len(train_loader):.4f}")

        #######################################################
        # Validation
        #######################################################

        model.eval()

        y_true=[]

        y_pred=[]

        y_prob=[]

        with torch.no_grad():

            for x,y in test_loader:

                x=x.to(device)

                y=y.to(device)

                outputs=model(x)

                probs=torch.softmax(outputs,dim=1)

                pred=torch.argmax(outputs,dim=1)

                y_true.extend(y.cpu().numpy())

                y_pred.extend(pred.cpu().numpy())

                y_prob.extend(probs[:,1].cpu().numpy())

        acc=accuracy_score(y_true,y_pred)

        print("Test Accuracy =",acc)

        if acc>best_acc:

            best_acc=acc

            torch.save(model.state_dict(),"best_CNN_transformer_model.pth")

    print("\nBest Accuracy =",best_acc)

    ###############################################################
    # Final Evaluation
    ###############################################################

    model.load_state_dict(torch.load("best_CNN_transformer_model.pth"))

    model.eval()

    y_true=[]

    y_pred=[]

    y_prob=[]

    with torch.no_grad():

        for x,y in test_loader:

            x=x.to(device)

            y=y.to(device)

            outputs=model(x)

            probs=torch.softmax(outputs,dim=1)

            pred=torch.argmax(outputs,dim=1)

            y_true.extend(y.cpu().numpy())

            y_pred.extend(pred.cpu().numpy())

            y_prob.extend(probs[:,1].cpu().numpy())

    accuracy=accuracy_score(y_true,y_pred)

    precision=precision_score(y_true,y_pred)

    recall=recall_score(y_true,y_pred)

    f1=f1_score(y_true,y_pred)

    auc=roc_auc_score(y_true,y_prob)

    cm=confusion_matrix(y_true,y_pred)

    print("\n============================")

    print("Accuracy :",accuracy)

    print("Precision:",precision)

    print("Recall   :",recall)

    print("F1-score :",f1)

    print("ROC AUC  :",auc)

    print("\nConfusion Matrix")

    print(cm)

    print("\nClassification Report")

    print(classification_report(y_true,y_pred))